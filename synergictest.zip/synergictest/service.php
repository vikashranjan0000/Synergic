<?php include "include/header.php"; ?>

    <!--HEADER-->
    <header>
        <div id="lgx-header" class="lgx-header">
            <div class="lgx-header-position lgx-header-position-white lgx-header-position-fixed "> <!--lgx-header-position-fixed lgx-header-position-white lgx-header-fixed-container lgx-header-fixed-container-gap lgx-header-position-white-->
                <div class="lgx-container"> <!--lgx-container-fluid-->
                    <nav class="navbar navbar-default lgx-navbar">
                        <div class="navbar-header">
                            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                                <span class="sr-only">Toggle navigation</span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>
                            <div class="lgx-logo">
                                <a href="index.html" class="lgx-scroll">
                                    <img src="http://placehold.it/400x72" alt="Logo"/>
                                </a>
                            </div>
                        </div>
                        <div id="navbar" class="navbar-collapse collapse">
                            <div class="lgx-nav-right navbar-right">
                                <div class="lgx-cart-area">
                                    <a class="lgx-btn lgx-btn-red" href="appoinment.html"><span>Appoinment</span></a>
                                </div>
                            </div>
                            <ul class="nav navbar-nav lgx-nav navbar-right">
                                <li>
                                    <a href="index.html" class="dropdown-toggle active" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Home <span class="caret"></span></a>
                                    <ul class="dropdown-menu multi-level">
                                        <li><a href="index.html">Home (Default)</a></li>
                                        <li><a href="index2.html">Home Banner</a></li>
                                        <li><a href="index3.html">Home Banner Two</a></li>
                                        <li><a href="index4.html">Home Typed</a></li>
                                        <li><a href="index-slider.html">Home Slider</a></li>
                                    </ul>
                                <li>
                                <li>
                                    <a href="index.html" class="dropdown-toggle active" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Pages <span class="caret"></span></a>
                                    <ul class="dropdown-menu multi-level">
                                        <li><a href="about.html">About</a></li>
                                        <li class="dropdown-submenu">
                                            <a href="#" class="dropdown-toggle active" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Doctors <span class="caret"></span></a>
                                            <ul class="dropdown-menu">
                                                <li><a href="doctors.html">Doctors List</a></li>
                                                <li><a href="doctor.html">Doctors Single</a></li>
                                            </ul>
                                        </li>
                                        <li><a href="services.html">Services List</a></li>
                                        <li><a href="appoinment.html">Appoinment</a></li>
                                        <li class="dropdown-submenu">
                                            <a href="#" class="dropdown-toggle active" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">News <span class="caret"></span></a>
                                            <ul class="dropdown-menu">
                                                <li><a href="news.html">News</a></li>
                                                <li><a href="news-single.html">News Single</a></li>
                                            </ul>
                                        </li>
                                        <li><a href="contact.html">Contact</a></li>
                                        <li class="dropdown-submenu">
                                            <a href="#" class="dropdown-toggle active" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Dropdown <span class="caret"></span></a>
                                            <ul class="dropdown-menu">
                                                <li class="dropdown-submenu">
                                                    <a href="#" class="dropdown-toggle active" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Dropdown Two<span class="caret"></span></a>
                                                    <ul class="dropdown-menu">
                                                        <li><a href="#">Dropdown Three</a></li>
                                                        <li><a href="#">Dropdown Three</a></li>
                                                    </ul>
                                                </li>
                                                <li><a href="#">Dropdown Two</a></li>
                                                <li><a href="#">Dropdown Two</a></li>
                                            </ul>
                                        </li>
                                    </ul>
                                </li>
                                <li><a class="lgx-scroll" href="doctors.html">Doctors</a></li>
                                <li><a class="lgx-scroll" href="services.html">Services</a></li>
                                <li><a class="lgx-scroll" href="news.html">News</a></li>
                                <li><a class="lgx-scroll" href="contact.html">Contact</a></li>
                            </ul>
                        </div><!--/.nav-collapse -->
                    </nav>
                </div>
                <!-- //.CONTAINER -->
            </div>
        </div>
    </header>
    <!--HEADER END-->

    <div id="content" class="content">
        <!--Banner Inner-->
        <section>
            <div class="lgx-banner lgx-banner-inner">
                <div class="lgx-page-inner">
                    <div class="container">
                        <div class="row">
                            <div class="col-xs-12">
                            </div>
                        </div><!--//.ROW-->
                    </div><!-- //.CONTAINER -->
                </div><!-- //.INNER -->
            </div>
        </section> <!--//.Banner Inner-->


        <main>
            <div class="lgx-post-wrapper">
                <!--News-->
                <section>
                    <div class="container">
                        <div class="row">
                            <div class="col-xs-12">
                                <article>
                                    <header>
                                        <figure>
                                            <img src="http://placehold.it/750x594" alt="New"/>
                                        </figure>
                                        <div class="text-area">
                                            <h1 class="title">Complete Medical Solutions</h1>
                                        </div>
                                    </header>
                                    <section>
                                        <p>
                                            Cras porttitor convallis ligula, at elementum erat mattis quis. In vitae vulputate tellus, sed laoreet est. Nam eget
                                            dolor non eros rutrum facilisis ut vel sapien. Aenean sed vehicula massa. Morbi imperdiet egestas ullamcorperet.
                                            Expo neque, congue nec nibh in, pellentesque fringilla risus. Suspendisse hendrerit et sapien ut pretium. Aenean
                                            nulla ipsum, facilisis eu porta non, rutrum sit amet nibh. Quisque id diam feugiat, pharetra arcu eget, bibendum
                                            tortor. Vivamus aliquam lacus id leo tristique sagittis. Pellentesque mattis diam metus, id commodo ex placerat
                                            vitae. Curabitur lobortis justo ante, in varius leo congue id. Etiam a libero elementum, posuere est at, sodales
                                            justo. Proin nec venenatis metus. Cras porttitor convallis ligula, at elementum erat mattis quis. In vitae vulputate
                                            tellus, sed laoreet est. Nam eget dolor non eros rutrum facilisis ut vel sapien. Aenean sed vehicula massa. Morbi
                                            imperdiet egestas ullamcorperet. Expo neque, congue nec nibh in, pellentesque fringilla risus. Suspendisse
                                            hendrerit et sapien ut pretium. Aenean nulla ipsum, facilisis eu porta non, rutrum sit amet nibh. Quisque id diam
                                            feugiat, pharetra arcu eget, bibendum tortor. Vivamus aliquam lacus id leo tristique sagittis. Pellentesque mattis
                                            diam metus, id commodo ex placerat vitae.
                                        </p>
                                    </section>
                                    <footer>
                                        <div class="row">
                                            <div class="col-xs-12">
                                                <h4 class="title">Share</h4>
                                                <div class="lgx-share">
                                                    <ul class="list-inline lgx-social">
                                                        <li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                                                        <li><a href="#"><i class="fa fa-facebook-f" aria-hidden="true"></i></a></li>
                                                        <li><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
                                                        <li><a href="#"><i class="fa fa-youtube-play" aria-hidden="true"></i></a></li>
                                                        <li><a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </footer>
                                </article>
                            </div>
                        </div>
                    </div><!-- //.CONTAINER -->
                </section>
                <!--News END-->
            </div>
        </main>
    </div>

<?php include "include/footer.php"; ?>