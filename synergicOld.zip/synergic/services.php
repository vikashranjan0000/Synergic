<?php include "include/header.php"; ?>
        <!--Banner Inner-->
        <section>
            <div class="lgx-banner lgx-banner-inner">
                <div class="lgx-page-inner">
                    <div class="container">
                        <div class="row">
                            <div class="col-xs-12">
                                <div class="lgx-heading-area">
                                    <div class="lgx-heading lgx-heading-white">
                                        <h2 class="heading">Our Best Services</h2>
                                    </div>
                                    <ul class="breadcrumb">
                                        <li><a href="index.html"><i class="fa fa-home" aria-hidden="true"></i>Home</a></li>
                                        <li class="active">Our Best Services</li>
                                    </ul>
                                </div>
                            </div>
                        </div><!--//.ROW-->
                    </div><!-- //.CONTAINER -->
                </div><!-- //.INNER -->
            </div>
        </section> <!--//.Banner Inner-->


        <main>
            <div class="lgx-page-wrapper">
                <!--News-->
                <section>
                    <div class="container">
                        <div class="row">
                            <div class="col-xs-12">
                                <div class="lgx-service-area lgx-service-area-similar">
                                    <div class="lgx-single-service">
                                        <figure>
                                            <a class="service-img" href="service.html"><img src="http://placehold.it/750x594" alt="Service"/></a>
                                            <figcaption>
                                                <div class="link-area">
                                                    <a href="#"><img src="assets/img/icons/icon-link.png" alt="link"></a>
                                                </div>
                                                <div class="service-info">
                                                    <h3 class="title"><a href="service.html">Medical Solutions</a></h3>
                                                    <p>Lorem ipsum dolor sit amet are consece sed do eiusmod tempor</p>
                                                    <a class="lgx-btn lgx-btn-white lgx-btn-sm" href="#"><span>Read More</span></a>
                                                    <img src="assets/img/services/icons/service-icon1.png" alt="service icon">
                                                </div>
                                            </figcaption>
                                        </figure>
                                    </div>
                                    <div class="lgx-single-service">
                                        <figure>
                                            <a class="service-img" href="service.html"><img src="http://placehold.it/750x594" alt="Service"/></a>
                                            <figcaption>
                                                <div class="link-area">
                                                    <a href="#"><img src="assets/img/icons/icon-link.png" alt="link"></a>
                                                </div>
                                                <div class="service-info">
                                                    <h3 class="title"><a href="service.html">Ear, Nose and Throat</a></h3>
                                                    <p>Lorem ipsum dolor sit amet are consece sed do eiusmod tempor</p>
                                                    <a class="lgx-btn lgx-btn-white lgx-btn-sm" href="#"><span>Read More</span></a>
                                                    <img src="assets/img/services/icons/service-icon2.png" alt="service icon">
                                                </div>
                                            </figcaption>
                                        </figure>
                                    </div>
                                    <div class="lgx-single-service">
                                        <figure>
                                            <a class="service-img" href="service.html"><img src="http://placehold.it/750x594" alt="Service"/></a>
                                            <figcaption>
                                                <div class="link-area">
                                                    <a href="#"><img src="assets/img/icons/icon-link.png" alt="link"></a>
                                                </div>
                                                <div class="service-info">
                                                    <h3 class="title"><a href="service.html">Bariatric Surgery</a></h3>
                                                    <p>Lorem ipsum dolor sit amet are consece sed do eiusmod tempor</p>
                                                    <a class="lgx-btn lgx-btn-white lgx-btn-sm" href="#"><span>Read More</span></a>
                                                    <img src="assets/img/services/icons/service-icon3.png" alt="service icon">
                                                </div>
                                            </figcaption>
                                        </figure>
                                    </div>
                                    <div class="lgx-single-service">
                                        <figure>
                                            <a class="service-img" href="service.html"><img src="http://placehold.it/750x594" alt="Service"/></a>
                                            <figcaption>
                                                <div class="link-area">
                                                    <a href="#"><img src="assets/img/icons/icon-link.png" alt="link"></a>
                                                </div>
                                                <div class="service-info">
                                                    <h3 class="title"><a href="service.html">Robotic Surgery</a></h3>
                                                    <p>Lorem ipsum dolor sit amet are consece sed do eiusmod tempor</p>
                                                    <a class="lgx-btn lgx-btn-white lgx-btn-sm" href="#"><span>Read More</span></a>
                                                    <img src="assets/img/services/icons/service-icon4.png" alt="service icon">
                                                </div>
                                            </figcaption>
                                        </figure>
                                    </div>
                                    <div class="lgx-single-service">
                                        <figure>
                                            <a class="service-img" href="service.html"><img src="http://placehold.it/750x594" alt="Service"/></a>
                                            <figcaption>
                                                <div class="link-area">
                                                    <a href="#"><img src="assets/img/icons/icon-link.png" alt="link"></a>
                                                </div>
                                                <div class="service-info">
                                                    <h3 class="title"><a href="service.html">Heart Program</a></h3>
                                                    <p>Lorem ipsum dolor sit amet are consece sed do eiusmod tempor</p>
                                                    <a class="lgx-btn lgx-btn-white lgx-btn-sm" href="#"><span>Read More</span></a>
                                                    <img src="assets/img/services/icons/service-icon5.png" alt="service icon">
                                                </div>
                                            </figcaption>
                                        </figure>
                                    </div>
                                    <div class="lgx-single-service">
                                        <figure>
                                            <a class="service-img" href="service.html"><img src="http://placehold.it/750x594" alt="Service"/></a>
                                            <figcaption>
                                                <div class="link-area">
                                                    <a href="#"><img src="assets/img/icons/icon-link.png" alt="link"></a>
                                                </div>
                                                <div class="service-info">
                                                    <h3 class="title"><a href="service.html">Ear, Nose and Throat</a></h3>
                                                    <p>Lorem ipsum dolor sit amet are consece sed do eiusmod tempor</p>
                                                    <a class="lgx-btn lgx-btn-white lgx-btn-sm" href="#"><span>Read More</span></a>
                                                    <img src="assets/img/services/icons/service-icon2.png" alt="service icon">
                                                </div>
                                            </figcaption>
                                        </figure>
                                    </div>
                                    <div class="lgx-single-service">
                                        <figure>
                                            <a class="service-img" href="service.html"><img src="http://placehold.it/750x594" alt="Service"/></a>
                                            <figcaption>
                                                <div class="link-area">
                                                    <a href="#"><img src="assets/img/icons/icon-link.png" alt="link"></a>
                                                </div>
                                                <div class="service-info">
                                                    <h3 class="title"><a href="service.html">Medical Solutions</a></h3>
                                                    <p>Lorem ipsum dolor sit amet are consece sed do eiusmod tempor</p>
                                                    <a class="lgx-btn lgx-btn-white lgx-btn-sm" href="#"><span>Read More</span></a>
                                                    <img src="assets/img/services/icons/service-icon1.png" alt="service icon">
                                                </div>
                                            </figcaption>
                                        </figure>
                                    </div>
                                    <div class="lgx-single-service">
                                        <figure>
                                            <a class="service-img" href="service.html"><img src="http://placehold.it/750x594" alt="Service"/></a>
                                            <figcaption>
                                                <div class="link-area">
                                                    <a href="#"><img src="assets/img/icons/icon-link.png" alt="link"></a>
                                                </div>
                                                <div class="service-info">
                                                    <h3 class="title"><a href="service.html">Ear, Nose and Throat</a></h3>
                                                    <p>Lorem ipsum dolor sit amet are consece sed do eiusmod tempor</p>
                                                    <a class="lgx-btn lgx-btn-white lgx-btn-sm" href="#"><span>Read More</span></a>
                                                    <img src="assets/img/services/icons/service-icon2.png" alt="service icon">
                                                </div>
                                            </figcaption>
                                        </figure>
                                    </div>
                                    <div class="lgx-single-service">
                                        <figure>
                                            <a class="service-img" href="service.html"><img src="http://placehold.it/750x594" alt="Service"/></a>
                                            <figcaption>
                                                <div class="link-area">
                                                    <a href="#"><img src="assets/img/icons/icon-link.png" alt="link"></a>
                                                </div>
                                                <div class="service-info">
                                                    <h3 class="title"><a href="service.html">Bariatric Surgery</a></h3>
                                                    <p>Lorem ipsum dolor sit amet are consece sed do eiusmod tempor</p>
                                                    <a class="lgx-btn lgx-btn-white lgx-btn-sm" href="#"><span>Read More</span></a>
                                                    <img src="assets/img/services/icons/service-icon3.png" alt="service icon">
                                                </div>
                                            </figcaption>
                                        </figure>
                                    </div>
                                    <div class="lgx-single-service">
                                        <figure>
                                            <a class="service-img" href="service.html"><img src="http://placehold.it/750x594" alt="Service"/></a>
                                            <figcaption>
                                                <div class="link-area">
                                                    <a href="#"><img src="assets/img/icons/icon-link.png" alt="link"></a>
                                                </div>
                                                <div class="service-info">
                                                    <h3 class="title"><a href="service.html">Robotic Surgery</a></h3>
                                                    <p>Lorem ipsum dolor sit amet are consece sed do eiusmod tempor</p>
                                                    <a class="lgx-btn lgx-btn-white lgx-btn-sm" href="#"><span>Read More</span></a>
                                                    <img src="assets/img/services/icons/service-icon4.png" alt="service icon">
                                                </div>
                                            </figcaption>
                                        </figure>
                                    </div>
                                    <div class="lgx-single-service">
                                        <figure>
                                            <a class="service-img" href="service.html"><img src="http://placehold.it/750x594" alt="Service"/></a>
                                            <figcaption>
                                                <div class="link-area">
                                                    <a href="#"><img src="assets/img/icons/icon-link.png" alt="link"></a>
                                                </div>
                                                <div class="service-info">
                                                    <h3 class="title"><a href="service.html">Heart Program</a></h3>
                                                    <p>Lorem ipsum dolor sit amet are consece sed do eiusmod tempor</p>
                                                    <a class="lgx-btn lgx-btn-white lgx-btn-sm" href="#"><span>Read More</span></a>
                                                    <img src="assets/img/services/icons/service-icon5.png" alt="service icon">
                                                </div>
                                            </figcaption>
                                        </figure>
                                    </div>
                                    <div class="lgx-single-service">
                                        <figure>
                                            <a class="service-img" href="service.html"><img src="http://placehold.it/750x594" alt="Service"/></a>
                                            <figcaption>
                                                <div class="link-area">
                                                    <a href="#"><img src="assets/img/icons/icon-link.png" alt="link"></a>
                                                </div>
                                                <div class="service-info">
                                                    <h3 class="title"><a href="service.html">Ear, Nose and Throat</a></h3>
                                                    <p>Lorem ipsum dolor sit amet are consece sed do eiusmod tempor</p>
                                                    <a class="lgx-btn lgx-btn-white lgx-btn-sm" href="#"><span>Read More</span></a>
                                                    <img src="assets/img/services/icons/service-icon2.png" alt="service icon">
                                                </div>
                                            </figcaption>
                                        </figure>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--//.ROW-->
                    </div><!-- //.CONTAINER -->
                </section>
                <!--News END-->
            </div>
        </main>
    </div>
<?php include "include/footer.php"; ?>