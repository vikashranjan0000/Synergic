<?php
/* ..............................................................................
 * Author:--------------- Themearth Team
 * AuthorEmail:-----------themearth.info@gmail.com
 * Technical Support:---- http://themearth.com/
 * Websites:------------- http://themearth.com/
 * Copyright:------------ Copyright (C) 2015 logichunt.com. All Rights Reserved.
 * License:-------------- http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * ..............................................................................
 * File:- subscribe-config.php
 ................................................................................ */

$save_in_csv    = false; // If You Want to save in csv format then set it true
$send_email     = true;
$api_key        = 'c9bee5a70d502b2939e274a8a64ae602-us11'; // MailChimp API KEY
$list_id        = 'd1c6438b35'; // MailChimp LIST ID
