<div class="row">
    <div class="col-xs-12">
        <div class="lgx-contact-form">
            <div class="lgx-contact-inner">
                <div class="lgx-contact-form-inline">
                    <span class="wpcf7-form-control-wrap your-name"><input type="text" name="your-name" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required" aria-required="true" aria-invalid="false" placeholder="Your Name ..."></span><br>
                    <span class="wpcf7-form-control-wrap your-email"><input type="email" name="your-email" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-email wpcf7-validates-as-required wpcf7-validates-as-email" aria-required="true" aria-invalid="false" placeholder="Your Email ..."></span><br>
                    <span class="wpcf7-form-control-wrap your-subject"><input type="text" name="your-subject" value="" size="40" class="wpcf7-form-control wpcf7-text" aria-invalid="false" placeholder="Subject Here ..."></span>
                </div>
                <p>   <span class="wpcf7-form-control-wrap your-message"><textarea name="your-message" cols="40" rows="10" class="wpcf7-form-control wpcf7-textarea" aria-invalid="false" placeholder="Write some text ..."></textarea></span>
                </p></div>
            <!--<p><span class="lgx-btn"><input type="submit" value="Send Massege" class="wpcf7-form-control wpcf7-submit"></span></p></div>-->
            <a class="lgx-btn" >Send Massege</a>
        </div>
    </div>
</div>