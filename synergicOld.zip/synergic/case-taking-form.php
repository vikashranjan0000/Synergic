<?php include "include/header.php"; ?>
        <!--Banner Inner-->
        <section>
            <div class="lgx-banner lgx-banner-inner">
                <div class="lgx-page-inner">
                    <div class="container">
                        <div class="row">
                            <div class="col-xs-12">

                            </div>
                        </div><!--//.ROW-->
                    </div><!-- //.CONTAINER -->
                </div><!-- //.INNER -->
            </div>
        </section> <!--//.Banner Inner-->


        <main>
            <div class="lgx-post-wrapper">
                <!--News-->
                <section>
                    <div class="container">
                        <div class="row">
                            <div class="col-xs-12">
                                <article>
                                    <header>
                                        <figure>
                                            <img src="assets/img/shri_logo.png" alt="New"/>
                                        </figure>
                                        <div class="text-area">                     
                                            <h1 class="title">Download Case Taking Form</h1>
                                        </div>
                                    </header>
                                    <section>
                                        
                                        <p>Download the form and send it by e-mail to <b>synergichomeopathy@gmail.com</b></p>
                                        <div>
                                            <p style="display: inline-block; margin-right: 20px;"><a href="assets/pdf/homeopathyform.pdf" target="_blank" class="lgx-btn"><span>Download Pdf</span></a></p>
                                            <p style="display: inline-block;"><a href="assets/pdf/homeopathyform.docx" target="_blank" class="lgx-btn"><span>Download Doc</span></a></p>
                                        </div>             
                                        <?php //include "contact-form.php";?>                                                        
                                    </section>
                         
                                </article>
                            </div>
                        </div>
                    </div><!-- //.CONTAINER -->
                </section>
                <!--News END-->
            </div>
        </main>
    </div>
<?php include "include/footer.php"; ?>